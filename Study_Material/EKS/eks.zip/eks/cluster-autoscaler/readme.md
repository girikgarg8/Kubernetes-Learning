https://github.com/kubernetes/autoscaler/issues/7389	

https://github.com/kubernetes/autoscaler/tree/master/cluster-autoscaler/cloudprovider/aws#Auto-discovery-setup